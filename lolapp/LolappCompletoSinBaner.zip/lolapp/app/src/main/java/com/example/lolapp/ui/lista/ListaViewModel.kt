package com.example.lolapp.ui.lista

class ListaViewModel {

    var NombreItem: String ?=null
    var RolItem: String ?=null
    var NivelItem: String ?=null

    constructor()
}