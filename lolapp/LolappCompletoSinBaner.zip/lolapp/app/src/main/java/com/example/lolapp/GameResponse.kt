package com.example.lolapp

class GameResponse : ArrayList<GameResponseItem>()