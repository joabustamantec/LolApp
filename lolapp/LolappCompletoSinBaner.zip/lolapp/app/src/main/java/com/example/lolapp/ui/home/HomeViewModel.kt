package com.example.lolapp.ui.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class HomeViewModel {

    var NombreCampeon: String ?=null
    var RolCampeon: String ?=null
    var PosicionCampeon: String ?=null

    constructor()
}