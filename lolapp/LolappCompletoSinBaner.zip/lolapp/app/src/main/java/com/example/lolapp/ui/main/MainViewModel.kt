package com.example.lolapp.ui.main

import androidx.lifecycle.ViewModel

class MainViewModel: ViewModel() {
}